PALACIO REMODELING — PRO Final
==============================

Incluye:
- index.html (navbar moderno, hero con overlay y mejor contraste, secciones pulidas)
- style.css (degradado animado elegante, paleta cálida, tipografías modernas, responsive)
- script.js (animaciones on-scroll, slider testimonios, menú móvil, año dinámico)
- send_mail.php (envío de formularios al correo)
- assets/logo/logo.png (reemplázalo por tu logo real si lo deseas)
- assets/img/ (placeholders listos para reemplazar por Pexels)
- favicon.ico corregido y vinculado en <head>

Cómo usar imágenes de Pexels:
1) Descarga tus fotos (fachadas/interiores) desde Pexels en alta calidad.
2) Renómbralas como: hero.jpg, project1.jpg, project2.jpg, project3.jpg, project4.jpg, service-kitchen.jpg, service-bath.jpg
3) Colócalas en assets/img/ (sustituye los archivos actuales). ¡Listo!

Configuración del formulario:
- Edita el correo destino en send_mail.php (variable $to).
- Requiere hosting con soporte PHP/mail(). Para SMTP usa PHPMailer.

Notas:
- El overlay del hero asegura legibilidad del texto sobre cualquier foto.
- El degradado animado del body es suave para no distraer.
- El favicon ya está enlazado y visible.
