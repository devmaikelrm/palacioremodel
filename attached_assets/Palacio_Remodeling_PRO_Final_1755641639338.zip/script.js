// Reveal on scroll
const observer = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('visible'); });
},{threshold:0.18});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

// Testimonials slider
let idx = 0;
const slides = document.querySelectorAll('.slide');
function rotate(){
  if(!slides.length) return;
  slides.forEach(s=>s.classList.remove('active'));
  idx = (idx + 1) % slides.length;
  slides[idx].classList.add('active');
}
if(slides.length){ slides[0].classList.add('active'); setInterval(rotate, 4200); }

// Year
document.getElementById('year')?.textContent = new Date().getFullYear();

// Mobile menu toggle
const toggle = document.querySelector('.menu-toggle');
const menu = document.querySelector('.menu');
toggle?.addEventListener('click', ()=>{
  if(menu.style.display === 'block'){ menu.style.display = 'none'; }
  else { menu.style.display = 'block'; }
});
