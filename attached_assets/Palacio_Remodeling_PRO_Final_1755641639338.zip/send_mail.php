<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method Not Allowed'); }
function clean($v){ return trim(strip_tags($v)); }
$name    = clean($_POST['name'] ?? '');
$email   = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$phone   = clean($_POST['phone'] ?? '');
$message = clean($_POST['message'] ?? '');
if (!$name || !$email || !$message) { http_response_code(400); exit('Faltan campos obligatorios.'); }
$to      = 'maikelreyesmorales95@gmail.com';
$subject = 'Nuevo contacto — Palacio Remodeling';
$body    = "Nombre: $name\nEmail: $email\nTeléfono: $phone\n\nMensaje:\n$message\n\n--\nWebsite: Palacio Remodeling";
$headers = "From: noreply@palacioremodeling.com\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8\r\n";
if (@mail($to, $subject, $body, $headers)) { echo '¡Gracias! Tu mensaje fue enviado.'; }
else { http_response_code(500); echo 'Error al enviar. Inténtalo más tarde.'; }
?>
